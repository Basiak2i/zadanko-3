const imie = document.querySelector('#imie');
const nazwisko = document.querySelector('#nazwisko');
const adres = document.querySelector('#adres');
const czysc = document.querySelector('#czysc');
const zapisz = document.querySelector('#submit');
const wynik = document.querySelector('#wynik');
const form = document.querySelector('form');

const lista = [];

function duze(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
};

form.addEventListener('submit', function(evt){
    evt.preventDefault();
    


    console.log(`imie: ${imie.value} naziwko: ${nazwisko.value} adres: ${adres.value}`);

    wynik.innerHTML = '';

    let user = {
        imie:duze(imie.value),
        nazwisko:duze(nazwisko.value),
        adres:duze(adres.value),
    };

    lista.push(user);

    lista.forEach(element => {
        wynik.innerHTML += `<li>Imie: ${element.imie} Nazwisko: ${element.nazwisko} Adres: ${element.adres}</li>`
        

        });

});

czysc.addEventListener("czysc", function(evt){
    evt.preventDefault();

    imie.value = " ";
    nazwisko.value = " ";
    adres.value = " "; 
})